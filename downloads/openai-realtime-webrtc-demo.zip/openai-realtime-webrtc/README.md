# Realtime WebRTC 本机示例

使用 Node.js 22 或更新版本，无需安装第三方包。在本目录执行：

```bash
export OPENAI_API_KEY='替换为自己的 API Key'
node server.mjs
```

在浏览器访问 http://localhost:3000，点击开始并允许麦克风访问。实际通话会将音频发送到 OpenAI 并产生 API 费用。

默认模型为 `gpt-realtime-2.1`，可通过 `OPENAI_REALTIME_MODEL` 改为支持此配置且项目有权限使用的模型，例如 `gpt-realtime-2.1-mini`。

服务端仅监听本机地址，长期 Key 不进入浏览器。公共服务需要单独配置 HTTPS、用户身份认证、请求限流与费用控制。此示例不包含业务工具、输入转写、重连恢复或持久化。

助手字幕反映生成内容，不能当作逐字对齐的播放记录。发生打断时，字幕可能包含未播放的内容。浏览器禁止自动播放时，可以手动点击音频控件。

验证范围：语法、模拟上游 HTTP 流程与静态页面构建。未用真实 API Key 进行通话测试。

官方接口参考：https://developers.openai.com/api/docs/guides/realtime-webrtc
