import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';

export const sessionConfig = {
  type: 'realtime',
  model: process.env.OPENAI_REALTIME_MODEL || 'gpt-realtime-2.1',
  output_modalities: ['audio'],
  reasoning: { effort: 'low' },
  instructions: '你是中文语音助手。回答简短自然；听不清时请用户重复。',
  audio: {
    input: {
      turn_detection: {
        type: 'semantic_vad',
        eagerness: 'medium',
        create_response: true,
        interrupt_response: true,
      },
    },
    output: { voice: 'marin' },
  },
};

// 仅供本机运行；公共服务需要自己的身份认证和用量控制。
export function createDemoServer({
  apiKey = process.env.OPENAI_API_KEY,
  fetchImpl = globalThis.fetch,
} = {}) {
  return createServer(async (req, res) => {
    const send = (status, content, type = 'text/plain; charset=utf-8') => {
      res.writeHead(status, { 'Content-Type': type, 'Cache-Control': 'no-store' });
      res.end(content);
    };
    try {
      if (!/^(localhost|127\.0\.0\.1):\d+$/.test(req.headers.host || '')) {
        return send(403, '请求来源不受支持。');
      }
      const files = {
        '/': ['index.html', 'text/html; charset=utf-8'],
        '/client.js': ['client.js', 'text/javascript; charset=utf-8'],
      };
      if (req.method === 'GET' && Object.hasOwn(files, req.url)) {
        const [file, type] = files[req.url];
        return send(200, await readFile(new URL(file, import.meta.url)), type);
      }
      if (req.method !== 'POST' || req.url !== '/session') {
        return send(404, '页面不存在。');
      }
      if (req.headers.origin !== `http://${req.headers.host}`) {
        return send(403, '请求来源不受支持。');
      }
      if (req.headers['content-type']?.split(';')[0] !== 'application/sdp') {
        return send(415, '请求必须使用 application/sdp。');
      }
      if (!apiKey) return send(503, '服务端尚未配置 OPENAI_API_KEY。');

      const chunks = [];
      let size = 0;
      for await (const chunk of req) {
        size += chunk.length;
        if (size > 64 * 1024) {
          send(413, '连接描述过大。');
          return;
        }
        chunks.push(chunk);
      }
      const sdp = Buffer.concat(chunks).toString('utf8');
      if (!sdp.startsWith('v=0')) return send(400, '连接描述无效。');

      const body = new FormData();
      body.set('sdp', sdp);
      body.set('session', JSON.stringify(sessionConfig));
      const upstream = await fetchImpl('https://api.openai.com/v1/realtime/calls', {
        method: 'POST',
        headers: { Authorization: `Bearer ${apiKey}` },
        body,
        signal: AbortSignal.timeout(20_000),
      });
      if (!upstream.ok) {
        // 不将上游详细错误、认证信息或音频内容回传给前端。
        return send(upstream.status, `OpenAI 会话创建失败（HTTP ${upstream.status}）。`);
      }
      return send(200, await upstream.text(), 'application/sdp');
    } catch (error) {
      if (!res.headersSent) {
        send(error.name === 'TimeoutError' ? 504 : 502, '语音服务连接失败。');
      }
    }
  });
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  createDemoServer().listen(3000, '127.0.0.1', () => {
    console.log('打开 http://localhost:3000，点击开始后授权麦克风。');
  });
}
