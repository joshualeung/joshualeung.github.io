const start = document.querySelector('#start');
const stop = document.querySelector('#stop');
const status = document.querySelector('#status');
const audio = document.querySelector('#audio');
const captions = document.querySelector('#captions');
const usage = document.querySelector('#usage');
let current;

function close(run, message) {
  clearTimeout(run.timer);
  run.controller.abort();
  if (run.channel) {
    run.channel.onclose = null;
    run.channel.close();
  }
  run.peer.onconnectionstatechange = null;
  run.peer.close();
  run.stream?.getTracks().forEach(track => track.stop());
  if (current === run) {
    current = undefined;
    audio.pause();
    audio.srcObject = null;
    start.disabled = false;
    stop.disabled = true;
    status.textContent = message;
  }
}

start.onclick = async () => {
  const run = {
    peer: new RTCPeerConnection(),
    controller: new AbortController(),
    rows: new Map(),
  };
  current = run;
  start.disabled = true;
  stop.disabled = false;
  captions.replaceChildren();
  usage.textContent = '';
  status.textContent = '正在申请麦克风权限并连接…';
  run.timer = setTimeout(() => close(run, '连接超时，请重试。'), 30_000);

  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true },
    });
    // 用户可能在权限对话框仍打开时结束连接。
    if (current !== run) {
      stream.getTracks().forEach(track => track.stop());
      return;
    }
    run.stream = stream;
    stream.getTracks().forEach(track => run.peer.addTrack(track, stream));
    run.peer.ontrack = event => {
      if (current !== run) return;
      audio.srcObject = event.streams[0];
      audio.play().catch(() => {
        if (current === run) status.textContent = '请点击音频控件播放回复。';
      });
    };
    run.peer.onconnectionstatechange = () => {
      if (['failed', 'disconnected'].includes(run.peer.connectionState)) {
        close(run, '连接已断开，请重新开始。');
      }
    };
    const channel = run.peer.createDataChannel('oai-events');
    run.channel = channel;
    channel.onopen = () => {
      if (current !== run) return;
      clearTimeout(run.timer);
      status.textContent = '已连接，可以开始讲话。';
    };
    channel.onclose = () => close(run, '会话已结束。');
    channel.onmessage = event => {
      if (current !== run) return;
      const message = JSON.parse(event.data);
      if (message.type === 'error') {
        close(run, '语音服务返回错误，请检查项目权限、额度或会话配置。');
      }
      if (message.type === 'response.output_audio_transcript.delta') {
        let row = run.rows.get(message.response_id);
        if (!row) {
          row = document.createElement('p');
          captions.append(row);
          run.rows.set(message.response_id, row);
          if (run.rows.size > 20) {
            const oldest = run.rows.keys().next().value;
            run.rows.get(oldest).remove();
            run.rows.delete(oldest);
          }
        }
        row.textContent += message.delta;
      }
      if (message.type === 'response.done') {
        const response = message.response;
        const row = run.rows.get(response.id);
        if (row && response.status !== 'completed') {
          row.textContent += ` [${response.status}：字幕可能包含未播放内容]`;
        }
        if (response.usage) {
          usage.textContent = `本轮输入 ${response.usage.input_tokens} token，输出 ${response.usage.output_tokens} token。`;
        }
      }
    };

    const offer = await run.peer.createOffer();
    await run.peer.setLocalDescription(offer);
    if (current !== run) return;
    const response = await fetch('/session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/sdp' },
      body: offer.sdp,
      signal: run.controller.signal,
    });
    if (!response.ok) throw new Error(await response.text());
    const sdp = await response.text();
    if (current !== run) return;
    await run.peer.setRemoteDescription({ type: 'answer', sdp });
  } catch (error) {
    if (current === run) close(run, `连接失败：${error.message}`);
  }
};

stop.onclick = () => current && close(current, '对话已结束，麦克风已关闭。');
window.addEventListener('pagehide', () => current && close(current, '页面已关闭。'));
